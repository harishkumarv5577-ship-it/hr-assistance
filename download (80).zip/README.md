# ResumeAI

ResumeAI is an AI-powered interview assistant designed to streamline the hiring process. It automatically parses resumes, generates relevant interview questions, conducts automated interviews, and extracts key skills from the conversation.

This project is a Next.js application built with Firebase Studio.

To get started, run `npm run dev` and open http://localhost:9002 in your browser.
