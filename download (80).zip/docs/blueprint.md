# **App Name**: ResumeAI

## Core Features:

- Resume Parsing: Automatically extract and parse information from uploaded resumes.
- Question Generation: Generate relevant interview questions based on the parsed resume data using AI as a tool.
- Automated Interview Execution: Conduct automated interviews by asking questions to the candidate.
- Response Recording: Record candidate responses during the interview for later analysis.
- Skills extraction: Use the AI model to extract skills of the user from the Resume, the response and the interview.

## Style Guidelines:

- Primary color: Deep sky blue (#00BFFF) to convey trust and efficiency.
- Background color: Light gray (#F0F8FF), a very pale blue tint, providing a professional backdrop that reduces eye strain.
- Accent color: Lemon yellow (#FFFACD) to highlight key information and interactive elements.
- Body font: 'PT Sans', sans-serif, a modern and clear typeface for optimal readability.
- Headline font: 'Space Grotesk', sans-serif, to bring a geometric and techy aesthetic.
- Use simple, professional icons to represent different sections of the resume and interview stages.
- Subtle transitions and loading animations to enhance user experience without being distracting.