import { config } from 'dotenv';
config();

import '@/ai/flows/extract-skills-from-resume.ts';
import '@/ai/flows/generate-interview-questions.ts';
import '@/ai/flows/extract-skills-from-interview.ts';
import '@/ai/flows/extract-text-from-resume.ts';
import '@/ai/flows/check-suitability.ts';
import '@/ai/flows/generate-interview-feedback.ts';
