'use server';

/**
 * @fileOverview Extracts skills from a resume using AI.
 *
 * - extractSkillsFromResume - A function that extracts skills from a resume.
 * - ExtractSkillsFromResumeInput - The input type for the extractSkillsFromResume function.
 * - ExtractSkillsFromResumeOutput - The return type for the extractSkillsFromResume function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const ExtractSkillsFromResumeInputSchema = z.object({
  resumeText: z.string().describe('The text content of the resume.'),
});

export type ExtractSkillsFromResumeInput = z.infer<
  typeof ExtractSkillsFromResumeInputSchema
>;

const ExtractSkillsFromResumeOutputSchema = z.object({
  skills: z
    .array(z.string())
    .describe('A list of skills extracted from the resume.'),
});

export type ExtractSkillsFromResumeOutput = z.infer<
  typeof ExtractSkillsFromResumeOutputSchema
>;

export async function extractSkillsFromResume(
  input: ExtractSkillsFromResumeInput
): Promise<ExtractSkillsFromResumeOutput> {
  return extractSkillsFromResumeFlow(input);
}

const extractSkillsFromResumePrompt = ai.definePrompt({
  name: 'extractSkillsFromResumePrompt',
  input: {schema: ExtractSkillsFromResumeInputSchema},
  output: {schema: ExtractSkillsFromResumeOutputSchema},
  prompt: `You are an expert in extracting skills from resumes.

  Given the following resume text, extract a list of skills that the candidate possesses.
  Return the skills as a JSON array of strings.

  Resume Text: {{{resumeText}}} `,
});

const extractSkillsFromResumeFlow = ai.defineFlow(
  {
    name: 'extractSkillsFromResumeFlow',
    inputSchema: ExtractSkillsFromResumeInputSchema,
    outputSchema: ExtractSkillsFromResumeOutputSchema,
  },
  async input => {
    const {output} = await extractSkillsFromResumePrompt(input);
    return output!;
  }
);
