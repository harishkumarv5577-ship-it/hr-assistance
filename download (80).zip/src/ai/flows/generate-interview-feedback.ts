
'use server';

/**
 * @fileOverview Generates feedback and a hiring recommendation on a candidate's interview performance.
 *
 * - generateInterviewFeedback - A function that analyzes an interview.
 * - GenerateInterviewFeedbackInput - The input type for the function.
 * - GenerateInterviewFeedbackOutput - The return type for the function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GenerateInterviewFeedbackInputSchema = z.object({
  jobDescription: z.string().describe('The job description for the role.'),
  resumeText: z.string().describe('The text content of the resume.'),
  interviewTranscript: z
    .string()
    .describe('The transcript of the interview, including questions and answers.'),
});

export type GenerateInterviewFeedbackInput = z.infer<
  typeof GenerateInterviewFeedbackInputSchema
>;

const GenerateInterviewFeedbackOutputSchema = z.object({
  feedback: z.string().describe("A summary of the candidate's performance."),
  strengths: z
    .array(z.string())
    .describe("A list of the candidate's key strengths."),
  areasForImprovement: z
    .array(z.string())
    .describe('A list of areas where the candidate could improve.'),
  selectionRecommendation: z.object({
    decision: z.enum(['Strong Hire', 'Hire', 'Maybe', 'No Hire']).describe('Final selection decision based on the interview.'),
    reasoning: z.string().describe('The reasoning for this selection decision based on the interview performance.'),
  }),
});

export type GenerateInterviewFeedbackOutput = z.infer<
  typeof GenerateInterviewFeedbackOutputSchema
>;

export async function generateInterviewFeedback(
  input: GenerateInterviewFeedbackInput
): Promise<GenerateInterviewFeedbackOutput> {
  return generateInterviewFeedbackFlow(input);
}

const generateFeedbackPrompt = ai.definePrompt({
  name: 'generateInterviewFeedbackPrompt',
  input: {schema: GenerateInterviewFeedbackInputSchema},
  output: {schema: GenerateInterviewFeedbackOutputSchema},
  prompt: `You are an expert hiring manager. Your task is to provide constructive feedback and a final hiring recommendation based on a candidate's interview performance.

Analyze the interview transcript in the context of the provided job description and the candidate's resume.

Based on your analysis, provide:
1. A concise summary of their overall performance.
2. A list of their key strengths demonstrated in the interview.
3. A list of areas where they could improve.
4. A final hiring recommendation: "Strong Hire", "Hire", "Maybe", or "No Hire", along with a clear reasoning.

Job Description:
{{jobDescription}}

Resume:
{{resumeText}}

Interview Transcript:
{{interviewTranscript}}
`,
});

const generateInterviewFeedbackFlow = ai.defineFlow(
  {
    name: 'generateInterviewFeedbackFlow',
    inputSchema: GenerateInterviewFeedbackInputSchema,
    outputSchema: GenerateInterviewFeedbackOutputSchema,
  },
  async input => {
    const {output} = await generateFeedbackPrompt(input);
    return output!;
  }
);
