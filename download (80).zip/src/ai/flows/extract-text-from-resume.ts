'use server';

/**
 * @fileOverview Extracts text from a resume file using Genkit.
 *
 * - extractTextFromResume - A function that extracts text from various resume file formats.
 * - ExtractTextFromResumeInput - The input type for the extractTextFromResume function.
 * - ExtractTextFromResumeOutput - The return type for the extractTextFromResume function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const ExtractTextFromResumeInputSchema = z.object({
  resumeFile: z
    .string()
    .describe(
      "A resume file, as a data URI that must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."
    ),
  mimeType: z.string().describe('The MIME type of the resume file.'),
});

export type ExtractTextFromResumeInput = z.infer<
  typeof ExtractTextFromResumeInputSchema
>;

const ExtractTextFromResumeOutputSchema = z.object({
  text: z.string().describe('The extracted text content of the resume.'),
});

export type ExtractTextFromResumeOutput = z.infer<
  typeof ExtractTextFromResumeOutputSchema
>;

export async function extractTextFromResume(
  input: ExtractTextFromResumeInput
): Promise<ExtractTextFromResumeOutput> {
  return extractTextFromResumeFlow(input);
}

const extractTextPrompt = ai.definePrompt({
  name: 'extractTextFromResumePrompt',
  input: {schema: ExtractTextFromResumeInputSchema},
  output: {schema: ExtractTextFromResumeOutputSchema},
  prompt: `You are an expert Optical Character Recognition (OCR) and text extraction tool. Your task is to accurately extract all text content from the provided resume file. Preserve the original formatting, including line breaks and spacing, as much as possible.

  File: {{media url=resumeFile}}`,
});

const extractTextFromResumeFlow = ai.defineFlow(
  {
    name: 'extractTextFromResumeFlow',
    inputSchema: ExtractTextFromResumeInputSchema,
    outputSchema: ExtractTextFromResumeOutputSchema,
  },
  async input => {
    const {output} = await extractTextPrompt(input);
    return output!;
  }
);
