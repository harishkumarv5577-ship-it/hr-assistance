'use server';

/**
 * @fileOverview A flow to check if a candidate is suitable for a job based on their resume.
 *
 * - checkSuitability - A function that checks candidate suitability.
 * - CheckSuitabilityInput - The input type for the checkSuitability function.
 * - CheckSuitabilityOutput - The return type for the checkSuitability function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const CheckSuitabilityInputSchema = z.object({
  resumeText: z
    .string()
    .describe('The text content of the resume to generate questions from.'),
  jobDescription: z
    .string()
    .describe('The job description for the role.'),
});
export type CheckSuitabilityInput = z.infer<
  typeof CheckSuitabilityInputSchema
>;

const CheckSuitabilityOutputSchema = z.object({
  isSuitable: z.boolean().describe('Whether the candidate is suitable for the job.'),
  reason: z.string().describe('The reasoning for the suitability assessment.'),
  suitabilityScore: z.number().min(0).max(10).describe('A suitability score from 0 to 10.'),
});
export type CheckSuitabilityOutput = z.infer<
  typeof CheckSuitabilityOutputSchema
>;

export async function checkSuitability(
  input: CheckSuitabilityInput
): Promise<CheckSuitabilityOutput> {
  return checkSuitabilityFlow(input);
}

const checkSuitabilityPrompt = ai.definePrompt({
  name: 'checkSuitabilityPrompt',
  input: {schema: CheckSuitabilityInputSchema},
  output: {schema: CheckSuitabilityOutputSchema},
  prompt: `You are an expert technical recruiter. Your task is to analyze a candidate's resume against a given job description and determine if they are a suitable match.

Based on the comparison, provide a suitability score from 0 to 10, where 10 is a perfect match. Also, provide a brief reasoning for your assessment. Set the isSuitable flag to true if the score is 6 or higher.

Job Description:
{{jobDescription}}

Resume Text:
{{resumeText}}
`, 
});

const checkSuitabilityFlow = ai.defineFlow(
  {
    name: 'checkSuitabilityFlow',
    inputSchema: CheckSuitabilityInputSchema,
    outputSchema: CheckSuitabilityOutputSchema,
  },
  async input => {
    const {output} = await checkSuitabilityPrompt(input);
    return output!;
  }
);
