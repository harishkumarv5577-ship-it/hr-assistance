'use server';

/**
 * @fileOverview Extracts skills from an interview transcript using Genkit.
 *
 * - extractSkillsFromInterview - A function that extracts skills from an interview transcript.
 * - ExtractSkillsFromInterviewInput - The input type for the extractSkillsFromInterview function.
 * - ExtractSkillsFromInterviewOutput - The return type for the extractSkillsFromInterview function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const ExtractSkillsFromInterviewInputSchema = z.object({
  resumeText: z.string().describe('The text content of the resume.'),
  interviewTranscript: z.string().describe('The transcript of the interview.'),
});

export type ExtractSkillsFromInterviewInput = z.infer<
  typeof ExtractSkillsFromInterviewInputSchema
>;

const ExtractSkillsFromInterviewOutputSchema = z.object({
  skills: z
    .array(z.string())
    .describe('A list of skills extracted from the interview transcript.'),
});

export type ExtractSkillsFromInterviewOutput = z.infer<
  typeof ExtractSkillsFromInterviewOutputSchema
>;

export async function extractSkillsFromInterview(
  input: ExtractSkillsFromInterviewInput
): Promise<ExtractSkillsFromInterviewOutput> {
  return extractSkillsFromInterviewFlow(input);
}

const extractSkillsPrompt = ai.definePrompt({
  name: 'extractSkillsPrompt',
  input: {schema: ExtractSkillsFromInterviewInputSchema},
  output: {schema: ExtractSkillsFromInterviewOutputSchema},
  prompt: `You are an expert in extracting skills from text. Given a resume and an interview transcript, extract the skills mentioned by the candidate.

Resume:
{{resumeText}}

Interview Transcript:
{{interviewTranscript}}

Skills:
`,
});

const extractSkillsFromInterviewFlow = ai.defineFlow(
  {
    name: 'extractSkillsFromInterviewFlow',
    inputSchema: ExtractSkillsFromInterviewInputSchema,
    outputSchema: ExtractSkillsFromInterviewOutputSchema,
  },
  async input => {
    const {output} = await extractSkillsPrompt(input);
    return output!;
  }
);
