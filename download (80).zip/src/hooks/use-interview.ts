
'use client';

import { useState } from 'react';
import { useFirestore } from '@/firebase';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { useToast } from './use-toast';
import type { Suitability } from '@/components/steps/suitability-step';
import type { InterviewFeedback } from '@/components/steps/results-step';

type InterviewData = {
    candidateName: string;
    jobDescription: string;
    resumeText: string;
    suitability: Suitability | null;
    feedback: InterviewFeedback | null;
};

export function useInterview() {
  const firestore = useFirestore();
  const [isSaving, setIsSaving] = useState(false);
  const { toast } = useToast();

  const saveInterviewRecord = async (interviewData: InterviewData) => {
    if (!firestore) {
        toast({
            variant: 'destructive',
            title: 'Firestore not available',
            description: 'Could not save the interview record.',
        });
        return;
    }
    setIsSaving(true);
    try {
      const interviewCollectionRef = collection(firestore, `interviews`);
      const docRef = await addDoc(interviewCollectionRef, {
        ...interviewData,
        conductedAt: serverTimestamp(),
      });
      toast({
        title: 'Interview Saved',
        description: 'The interview analysis has been saved to the dashboard.',
      });
      return docRef.id;
    } catch (error: any) {
      console.error('Failed to save interview record:', error);
      toast({
        variant: 'destructive',
        title: 'Failed to Save',
        description: error.message || 'Could not save the interview record.',
      });
      throw error;
    } finally {
      setIsSaving(false);
    }
  };

  return {
    saveInterviewRecord,
    isSaving,
  };
}
