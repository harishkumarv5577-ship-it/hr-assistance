
'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import {
  onIdTokenChanged,
  signInWithPopup,
  GoogleAuthProvider,
  signOut as firebaseSignOut,
  type User,
} from 'firebase/auth';
import { useFirebase } from '@/firebase/provider';
import Cookies from 'js-cookie';

const FIREBASE_ID_TOKEN = 'firebaseIdToken';

export function useAuth() {
  const { auth, isUserLoading: isFirebaseLoading, user: firebaseUser } = useFirebase();
  const [user, setUser] = useState<User | null>(firebaseUser);
  const [isUserLoading, setIsUserLoading] = useState(true);
  const router = useRouter();

  useEffect(() => {
    if (auth) {
      const unsubscribe = onIdTokenChanged(auth, async (newUser) => {
        setUser(newUser);
        setIsUserLoading(false);
        if (newUser) {
          const token = await newUser.getIdToken();
          Cookies.set(FIREBASE_ID_TOKEN, token, { expires: 1 });
        } else {
          Cookies.remove(FIREBASE_ID_TOKEN);
        }
      });
      return () => unsubscribe();
    }
  }, [auth]);
  
  useEffect(() => {
     if (!isFirebaseLoading) {
       setUser(firebaseUser);
       setIsUserLoading(false);
     }
  }, [firebaseUser, isFirebaseLoading]);

  const signInWithGoogle = async () => {
    if (!auth) return;
    setIsUserLoading(true);
    const provider = new GoogleAuthProvider();
    try {
      await signInWithPopup(auth, provider);
      router.push('/history');
    } catch (error: any) {
      if (error.code !== 'auth/popup-closed-by-user') {
        console.error('Error during sign-in:', error);
      }
      setIsUserLoading(false);
    }
  };

  const signOut = async () => {
    if (!auth) return;
    try {
      await firebaseSignOut(auth);
      router.push('/');
    } catch (error) {
      console.error('Error during sign-out:', error);
    }
  };

  return {
    user,
    isUserLoading,
    signInWithGoogle,
    signOut,
  };
}
