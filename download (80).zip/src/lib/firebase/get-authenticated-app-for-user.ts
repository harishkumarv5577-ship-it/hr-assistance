import { initializeApp, getApp, getApps, FirebaseOptions } from "firebase/app";
import { getAuth, signInWithCustomToken, User } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { headers } from "next/headers";
import { firebaseConfig } from "@/firebase/config";

// IMPORTANT: This function is not intended for client-side use.
export async function getAuthenticatedAppForUser() {
  const
    h = headers(),
    // These headers are forwarded by Firebase App Hosting.
    token = h.get("X-Firebase-AppCheck-Token") || h.get("X-Goog-Firebase-AppCheck-Token"),
    emulated = h.get("X-Firebase-Emulator-Request") === "true";

  if (!token && !emulated) {
    // If there's no App Check token and we're not using an emulator, we can't authenticate.
    return { firebase: null, user: null };
  }

  const app = initializeAuthenticatedApp(firebaseConfig);
  const auth = getAuth(app);
  const firestore = getFirestore(app);

  let user: User | null = null;
  if (!emulated) {
    // In a production environment, we use the App Check token to authenticate.
    try {
      const userCredential = await signInWithCustomToken(auth, token as string);
      user = userCredential.user;
    } catch (e) {
      console.error("Custom token sign-in error", e);
    }
  } else {
    // In an emulated environment, we may have a user from the client.
    // For this example, we'll assume a dummy user for server-side logic.
    // In a real app, you might pass user info through headers.
    user = auth.currentUser;
  }

  return { firebase: { app, auth, firestore }, user };
}

function initializeAuthenticatedApp(options: FirebaseOptions) {
  const random = Math.random().toString(36).substring(7);
  // Using a random name ensures that we don't try to initialize the same app twice.
  return getApps().length ? getApp() : initializeApp(options, `auth-app-${random}`);
}
