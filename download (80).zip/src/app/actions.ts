"use server";

import { z } from "zod";
import { generateInterviewQuestions } from "@/ai/flows/generate-interview-questions";
import { extractSkillsFromResume } from "@/ai/flows/extract-skills-from-resume";
import { extractSkillsFromInterview } from "@/ai/flows/extract-skills-from-interview";
import { extractTextFromResume } from "@/ai/flows/extract-text-from-resume";
import { checkSuitability } from "@/ai/flows/check-suitability";
import { generateInterviewFeedback } from "@/ai/flows/generate-interview-feedback";

const startInterviewSchema = z.object({
  jobDescription: z.string(),
  resumeText: z.string().optional(),
  resumeFile: z.string().optional(), // data URI
  mimeType: z.string().optional(),
}).refine(data => data.resumeText || data.resumeFile, {
    message: "Either resume text or a file must be provided.",
});


export async function startInterviewAction(input: { jobDescription: string, resumeText?: string, resumeFile?: string, mimeType?: string }) {
  const parsedInput = startInterviewSchema.safeParse(input);
  if (!parsedInput.success) {
    throw new Error(parsedInput.error.errors[0].message);
  }

  let resumeText = parsedInput.data.resumeText;

  // If a file is provided, extract text from it.
  if (parsedInput.data.resumeFile && parsedInput.data.mimeType) {
    const extractedTextResult = await extractTextFromResume({
        resumeFile: parsedInput.data.resumeFile,
        mimeType: parsedInput.data.mimeType,
    });
    if (!extractedTextResult || !extractedTextResult.text) {
        throw new Error("Could not extract text from the provided file.");
    }
    resumeText = extractedTextResult.text;
  }
  
  if (!resumeText) {
    throw new Error("Could not get resume text.");
  }

  const [questionsResult, skillsResult, suitabilityResult] = await Promise.all([
    generateInterviewQuestions({ resumeText, jobDescription: parsedInput.data.jobDescription }),
    extractSkillsFromResume({ resumeText }),
    checkSuitability({ resumeText, jobDescription: parsedInput.data.jobDescription }),
  ]);

  return {
    questions: questionsResult?.questions ?? [],
    skills: skillsResult?.skills ?? [],
    resumeText: resumeText, // Return the extracted text
    suitability: suitabilityResult,
  };
}

const analyzeInterviewSchema = z.object({
  jobDescription: z.string().min(1, "Job description cannot be empty."),
  resumeText: z.string().min(1, "Resume text cannot be empty."),
  interviewTranscript: z.string().min(1, "Interview transcript cannot be empty."),
});

export async function analyzeInterviewAction(input: {
  jobDescription: string;
  resumeText: string;
  interviewTranscript: string;
}) {
  const parsedInput = analyzeInterviewSchema.safeParse(input);
  if (!parsedInput.success) {
    throw new Error(parsedInput.error.errors[0].message);
  }

  const [skillsResult, feedbackResult] = await Promise.all([
    extractSkillsFromInterview({
      resumeText: parsedInput.data.resumeText,
      interviewTranscript: parsedInput.data.interviewTranscript,
    }),
    generateInterviewFeedback({
      jobDescription: parsedInput.data.jobDescription,
      resumeText: parsedInput.data.resumeText,
      interviewTranscript: parsedInput.data.interviewTranscript,
    })
  ]);

  if (!feedbackResult) {
    throw new Error("Failed to generate interview feedback.");
  }

  return {
    skills: skillsResult?.skills ?? [],
    feedback: feedbackResult,
  };
}
