
'use client';

import { useRouter } from 'next/navigation';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Loader2, User, Palette, ShieldAlert, ArrowLeft } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { ThemeToggle } from '@/components/theme-toggle';


export default function SettingsPage() {
  const router = useRouter();

  return (
    <div className="container mx-auto py-8 md:py-12 w-full max-w-2xl animate-in fade-in-50">
        <div className="flex items-center gap-4 mb-8">
            <Button variant="outline" size="icon" onClick={() => router.back()}>
                <ArrowLeft />
                <span className="sr-only">Back</span>
            </Button>
            <h1 className="font-headline text-3xl font-bold">Settings</h1>
        </div>


        {/* Profile Section */}
        <Card className="mb-8">
            <CardHeader>
            <CardTitle className="flex items-center gap-2">
                <User /> Profile
            </CardTitle>
            <CardDescription>
                This feature is coming soon.
            </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
                <div className='w-full space-y-2 opacity-50'>
                    <div className="space-y-1">
                        <Label htmlFor="displayName">Display Name</Label>
                        <Input id="displayName" defaultValue="User" disabled />
                    </div>
                <div className="space-y-1">
                    <Label htmlFor="email">Email Address</Label>
                    <Input id="email" readOnly defaultValue="user@example.com" disabled />
                </div>
            </div>
            </CardContent>
            <CardFooter>
            <Button disabled>Save Changes</Button>
            </CardFooter>
        </Card>
        
        {/* Appearance Section */}
        <Card className="mb-8">
            <CardHeader>
            <CardTitle className="flex items-center gap-2">
                <Palette /> Appearance
            </CardTitle>
            <CardDescription>
                Customize the look and feel of the application.
            </CardDescription>
            </CardHeader>
            <CardContent>
            <ThemeToggle />
            </CardContent>
        </Card>

        {/* Account Section */}
        <Card className="border-destructive">
            <CardHeader>
            <CardTitle className="flex items-center gap-2 text-destructive">
                <ShieldAlert /> Danger Zone
            </CardTitle>
            <CardDescription>
                These actions are permanent and cannot be undone.
            </CardDescription>
            </CardHeader>
            <CardContent>
                <div className="flex items-center justify-between rounded-lg border border-destructive/50 p-4">
                    <div>
                        <h4 className="font-semibold">Delete Account</h4>
                        <p className="text-sm text-muted-foreground">Permanently delete your account and all associated data.</p>
                    </div>
                    <Button variant="destructive" disabled>Delete Account</Button>
                </div>
            </CardContent>
        </Card>
    </div>
  );
}
