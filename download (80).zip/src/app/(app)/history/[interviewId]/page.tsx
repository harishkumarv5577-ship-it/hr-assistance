'use client';

import { useParams, useRouter } from 'next/navigation';
import { useDoc, useMemoFirebase, useFirestore } from '@/firebase';
import { doc } from 'firebase/firestore';
import { Loader2, Star, TrendingUp, TrendingDown, CheckCircle, XCircle, ArrowLeft, Calendar, UserCheck, Briefcase } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Button } from '@/components/ui/button';
import { format } from 'date-fns';

interface InterviewRecord {
  id: string;
  candidateName: string;
  jobDescription: string;
  conductedAt: { seconds: number; nanoseconds: number } | null;
  suitability: {
    suitabilityScore: number;
    isSuitable: boolean;
    reason: string;
  };
  feedback: {
    feedback: string;
    strengths: string[];
    areasForImprovement: string[];
    selectionRecommendation?: {
      decision: string;
      reasoning: string;
    };
  };
}

export default function InterviewDetailsPage() {
  const params = useParams();
  const router = useRouter();
  const firestore = useFirestore();
  const interviewId = params.interviewId as string;

  const interviewDocRef = useMemoFirebase(() => {
    if (!firestore || !interviewId) return null;
    return doc(firestore, 'interviews', interviewId);
  }, [firestore, interviewId]);

  const { data: interview, isLoading, error } = useDoc<InterviewRecord>(interviewDocRef);

  if (isLoading) {
    return (
      <div className="flex h-[80vh] w-full items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="h-10 w-10 animate-spin text-primary" />
          <p className="text-muted-foreground animate-pulse font-medium">Retrieving Report...</p>
        </div>
      </div>
    );
  }

  if (error || !interview) {
    return (
      <div className="container mx-auto py-12 px-4 max-w-2xl text-center">
        <div className="bg-destructive/10 p-6 rounded-2xl mb-6">
          <XCircle className="h-12 w-12 text-destructive mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-destructive mb-2">Interview Not Found</h2>
          <p className="text-muted-foreground">
            {error?.message || 'We couldn\'t find the requested interview record in our database.'}
          </p>
        </div>
        <Button onClick={() => router.push('/history')} variant="outline" className="rounded-full">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to History
        </Button>
      </div>
    );
  }

  const date = interview.conductedAt 
    ? new Date(interview.conductedAt.seconds * 1000) 
    : new Date();

  const recommendation = interview.feedback?.selectionRecommendation;
  const decisionColors: Record<string, string> = {
    'Strong Hire': 'bg-emerald-600 text-white',
    'Hire': 'bg-emerald-500 text-white',
    'Maybe': 'bg-amber-500 text-white',
    'No Hire': 'bg-rose-600 text-white',
  };
  const decisionColor = recommendation ? decisionColors[recommendation.decision] || 'bg-muted text-muted-foreground' : 'bg-muted';

  return (
    <div className="container mx-auto py-8 px-4 md:py-12 max-w-5xl animate-in fade-in duration-700 slide-in-from-bottom-4">
      <Button variant="ghost" className="mb-8 hover:bg-secondary rounded-full" onClick={() => router.push('/history')}>
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back to History
      </Button>

      <div className="flex flex-col lg:flex-row lg:items-center justify-between mb-12 gap-8">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-bold mb-3">
            <Briefcase className="h-3 w-3" />
            Interview Analysis Report
          </div>
          <h1 className="font-headline text-5xl md:text-6xl font-black tracking-tight">{interview.candidateName}</h1>
          <div className="flex items-center gap-2 text-muted-foreground mt-4 text-lg">
            <Calendar className="h-5 w-5" />
            <span>{format(date, 'MMMM d, yyyy')} at {format(date, 'h:mm a')}</span>
          </div>
        </div>
        <div className="flex flex-wrap gap-4 items-start lg:items-end flex-col">
            <Badge 
              variant={interview.suitability.isSuitable ? "default" : "destructive"} 
              className="text-lg px-6 py-2 rounded-full shadow-sm"
            >
              Resume: {interview.suitability.isSuitable ? 'Recommended' : 'Not Recommended'}
            </Badge>
            {recommendation && (
                <Badge className={`${decisionColor} text-lg px-6 py-2 rounded-full shadow-md`}>
                    Final Result: {recommendation.decision}
                </Badge>
            )}
        </div>
      </div>

      <div className="grid gap-8">
        {recommendation && (
            <Card className="shadow-2xl border-none overflow-hidden bg-gradient-to-br from-white to-secondary/30">
                <div className={`${decisionColor.split(' ')[0]} h-3 w-full`} />
                <CardHeader className="pb-2">
                    <CardTitle className="flex items-center gap-3 text-3xl font-headline">
                        <UserCheck className="h-8 w-8 text-primary" />
                        Selection Recommendation
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6 pt-4">
                    <div className="flex items-baseline gap-3">
                        <span className="text-xl font-medium text-muted-foreground">Conclusion:</span>
                        <span className={`text-4xl font-black ${recommendation.decision.includes('Hire') ? 'text-emerald-600' : 'text-rose-600'}`}>
                          {recommendation.decision}
                        </span>
                    </div>
                    <div className="bg-white/80 p-6 rounded-2xl border shadow-inner italic text-lg leading-relaxed text-foreground/90">
                        "{recommendation.reasoning}"
                    </div>
                </CardContent>
            </Card>
        )}

        <div className="grid md:grid-cols-3 gap-8">
          <Card className="md:col-span-2 shadow-xl border-none">
            <CardHeader>
              <CardTitle className="text-2xl font-headline flex items-center gap-2">
                <Briefcase className="text-primary h-6 w-6" />
                Resume Suitability
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-lg text-muted-foreground leading-relaxed italic">
                {interview.suitability.reason}
              </p>
            </CardContent>
          </Card>
          
          <Card className="shadow-xl border-none bg-primary text-white overflow-hidden relative">
            <div className="absolute -right-4 -bottom-4 opacity-10">
              <Star size={120} strokeWidth={1} />
            </div>
            <CardContent className="flex flex-col items-center justify-center h-full py-10">
              <p className="text-sm font-bold uppercase tracking-[0.2em] mb-4 opacity-80">Suitability Score</p>
              <div className="text-8xl font-black flex items-baseline">
                {interview.suitability.suitabilityScore}
                <span className="text-3xl font-medium opacity-60">/10</span>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="shadow-xl border-none">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-2xl font-headline">
              <Star className="text-primary h-7 w-7" />
              Interview Performance Analysis
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-10">
            <div className="bg-secondary/50 p-6 rounded-2xl italic text-xl text-muted-foreground border-l-4 border-primary">
              "{interview.feedback.feedback}"
            </div>
            
            <div className="grid md:grid-cols-2 gap-10">
              <div className="space-y-6">
                <h4 className="font-black text-xl text-emerald-600 flex items-center gap-3 font-headline">
                  <div className="bg-emerald-100 p-2 rounded-lg"><TrendingUp className="h-6 w-6" /></div>
                  Candidate Strengths
                </h4>
                <ul className="space-y-4">
                  {interview.feedback.strengths.map((s, i) => (
                    <li key={i} className="flex items-start gap-3 text-lg text-muted-foreground bg-secondary/20 p-3 rounded-xl">
                      <CheckCircle className="h-5 w-5 text-emerald-500 mt-1 flex-shrink-0" />
                      <span>{s}</span>
                    </li>
                  ))}
                </ul>
              </div>
              
              <div className="space-y-6">
                <h4 className="font-black text-xl text-amber-600 flex items-center gap-3 font-headline">
                  <div className="bg-amber-100 p-2 rounded-lg"><TrendingDown className="h-6 w-6" /></div>
                  Development Areas
                </h4>
                <ul className="space-y-4">
                  {interview.feedback.areasForImprovement.map((a, i) => (
                    <li key={i} className="flex items-start gap-3 text-lg text-muted-foreground bg-secondary/20 p-3 rounded-xl">
                      <XCircle className="h-5 w-5 text-amber-500 mt-1 flex-shrink-0" />
                      <span>{a}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-secondary/20 border-none shadow-sm">
          <CardHeader>
            <CardTitle className="text-xl font-headline">Job Context & Requirements</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="max-h-80 overflow-y-auto rounded-2xl border bg-white p-6 text-base leading-relaxed whitespace-pre-wrap text-muted-foreground shadow-inner">
              {interview.jobDescription}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}