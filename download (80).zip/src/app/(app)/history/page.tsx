
'use client';

import { useRouter } from 'next/navigation';
import { useCollection, useFirestore, useMemoFirebase } from '@/firebase';
import { collection } from 'firebase/firestore';
import { Loader2, PlusCircle, Frown, Smile, AlertCircle, Clock, CheckCircle2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { formatDistanceToNow } from 'date-fns';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

interface InterviewRecord {
  id: string;
  candidateName: string;
  conductedAt: { seconds: number; nanoseconds: number } | null;
  suitability: {
    suitabilityScore: number;
    isSuitable: boolean;
    reason: string;
  };
  feedback: {
    feedback: string;
    strengths: string[];
    areasForImprovement: string[];
    selectionRecommendation?: {
      decision: string;
      reasoning: string;
    };
  };
}

export default function HistoryPage() {
  const router = useRouter();
  const firestore = useFirestore();

  // Simplified query to avoid index issues and potential hangs
  const interviewsQuery = useMemoFirebase(() => {
    if (!firestore) return null;
    return collection(firestore, 'interviews');
  }, [firestore]);

  const { data: interviews, isLoading, error } = useCollection<InterviewRecord>(interviewsQuery);

  if (isLoading) {
    return (
      <div className="flex h-[60vh] w-full items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="h-10 w-10 animate-spin text-primary" />
          <p className="text-muted-foreground animate-pulse">Loading interviews...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mx-auto py-12 px-4 max-w-4xl">
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error Loading History</AlertTitle>
          <AlertDescription>
            {error.message || 'There was a problem fetching the interview records.'}
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  if (!interviews || interviews.length === 0) {
    return (
      <div className="container mx-auto py-12 px-4 text-center max-w-4xl">
        <div className="max-w-md mx-auto py-20 rounded-xl border-2 border-dashed border-border bg-card/50">
          <h3 className="text-xl font-bold mb-2">No interviews yet</h3>
          <p className="text-muted-foreground mb-6">
            Conduct your first AI-powered interview to see the analysis here.
          </p>
          <Button onClick={() => router.push('/interview')}>
            <PlusCircle className="mr-2 h-4 w-4" />
            Start New Interview
          </Button>
        </div>
      </div>
    );
  }

  // Sort interviews client-side safely
  const sortedInterviews = [...interviews].sort((a, b) => {
    const timeA = a.conductedAt?.seconds || 0;
    const timeB = b.conductedAt?.seconds || 0;
    return timeB - timeA;
  });

  return (
    <div className="container mx-auto py-8 px-4 max-w-7xl animate-in fade-in duration-500">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-10 gap-4">
        <div>
          <h1 className="font-headline text-4xl font-bold tracking-tight">Interview History</h1>
          <p className="text-muted-foreground mt-1">Review and manage your candidate assessments.</p>
        </div>
        <Button onClick={() => router.push('/interview')} size="lg" className="shadow-lg">
          <PlusCircle className="mr-2 h-5 w-5" />
          New Interview
        </Button>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {sortedInterviews.map((record) => {
          const decision = record.feedback?.selectionRecommendation?.decision;
          const decisionColor = 
            decision === 'Strong Hire' ? 'bg-green-600' : 
            decision === 'Hire' ? 'bg-green-500' : 
            decision === 'Maybe' ? 'bg-amber-500' : 
            'bg-red-500';

          return (
            <Card key={record.id} className="flex flex-col hover:border-primary/50 transition-all shadow-sm">
              <CardHeader className="pb-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <CardTitle className="font-headline text-xl truncate">
                      {record.candidateName}
                    </CardTitle>
                    <CardDescription className="mt-1 flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {record.conductedAt
                        ? formatDistanceToNow(new Date(record.conductedAt.seconds * 1000), { addSuffix: true })
                        : 'Recently'}
                    </CardDescription>
                  </div>
                  {decision && (
                    <Badge className={`${decisionColor} text-white font-bold whitespace-nowrap`}>
                      {decision}
                    </Badge>
                  )}
                </div>
              </CardHeader>
              <CardContent className="flex-grow text-sm">
                <div className="flex items-center gap-2 font-medium mb-2">
                  {record.suitability?.isSuitable ? (
                    <Smile className="text-green-500 h-4 w-4" />
                  ) : (
                    <Frown className="text-red-500 h-4 w-4" />
                  )}
                  <span>{record.suitability?.isSuitable ? 'Recommended' : 'Not Recommended'}</span>
                </div>
                <p className="text-muted-foreground line-clamp-2 italic">
                  "{record.feedback?.selectionRecommendation?.reasoning || record.feedback?.feedback || record.suitability?.reason}"
                </p>
              </CardContent>
              <CardFooter className="pt-2">
                <Button 
                  variant="secondary" 
                  className="w-full" 
                  onClick={() => router.push(`/history/${record.id}`)}
                >
                  View Full Report
                </Button>
              </CardFooter>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
