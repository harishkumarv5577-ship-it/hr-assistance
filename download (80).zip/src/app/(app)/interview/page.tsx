
'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import JobDescriptionStep from '@/components/steps/job-description-step';
import ResumeInputStep from '@/components/steps/resume-input-step';
import SuitabilityStep, { type Suitability } from '@/components/steps/suitability-step';
import InterviewStep from '@/components/steps/interview-step';
import ResultsStep, { type InterviewFeedback } from '@/components/steps/results-step';
import { startInterviewAction, analyzeInterviewAction } from '@/app/actions';
import { useInterview } from '@/hooks/use-interview';
import { Loader2, ServerCrash } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

type Step =
  | 'JOB_DESCRIPTION'
  | 'RESUME_INPUT'
  | 'SUITABILITY_CHECK'
  | 'INTERVIEW'
  | 'ANALYZING'
  | 'RESULTS'
  | 'ERROR';

export default function InterviewPage() {
  const [step, setStep] = useState<Step>('JOB_DESCRIPTION');
  const [jobDescription, setJobDescription] = useState('');
  const [candidateName, setCandidateName] = useState('');
  const [resumeText, setResumeText] = useState('');
  const [questions, setQuestions] = useState<string[]>([]);
  const [resumeSkills, setResumeSkills] = useState<string[]>([]);
  const [suitability, setSuitability] = useState<Suitability | null>(null);
  const [interviewSkills, setInterviewSkills] = useState<string[]>([]);
  const [interviewFeedback, setInterviewFeedback] = useState<InterviewFeedback | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [lastInterviewId, setLastInterviewId] = useState<string | null>(null);

  const router = useRouter();
  const { saveInterviewRecord } = useInterview();

  const handleJobDescriptionNext = (data: { jobDescription: string }) => {
    setJobDescription(data.jobDescription);
    setStep('RESUME_INPUT');
  };

  const handleResumeBack = () => {
    setStep('JOB_DESCRIPTION');
  };

  const handleStartInterview = async (data: {
    candidateName: string;
    resumeText?: string;
    resumeFile?: string;
    mimeType?: string;
  }) => {
    setCandidateName(data.candidateName);
    setStep('SUITABILITY_CHECK');
    try {
      const result = await startInterviewAction({ jobDescription, ...data });
      if (result) {
        setQuestions(result.questions);
        setResumeSkills(result.skills);
        setResumeText(result.resumeText); // Save the potentially extracted resume text
        if (result.suitability) {
          setSuitability(result.suitability);
          setStep('SUITABILITY_CHECK');
        } else {
           // If no suitability, go straight to interview
           setStep('INTERVIEW');
        }
      }
    } catch (e: any) {
      console.error(e);
      setError(e.message || 'Failed to start interview.');
      setStep('ERROR');
    }
  };

  const handleSuitabilityBack = () => {
    setStep('RESUME_INPUT');
  }

  const handleProceedToInterview = () => {
    setStep('INTERVIEW');
  };

  const handleFinishInterview = async (answers: string[]) => {
    setStep('ANALYZING');
    const interviewTranscript = questions
      .map((q, i) => `Question: ${q}\nAnswer: ${answers[i]}`)
      .join('\n\n');

    try {
      const analysisResult = await analyzeInterviewAction({
        jobDescription,
        resumeText,
        interviewTranscript,
      });

      if (analysisResult) {
        setInterviewSkills(analysisResult.skills);
        setInterviewFeedback(analysisResult.feedback);

        const newInterviewId = await saveInterviewRecord({
            candidateName,
            jobDescription,
            resumeText,
            suitability,
            feedback: analysisResult.feedback
        });
        if (newInterviewId) {
          setLastInterviewId(newInterviewId);
        }
      }
      setStep('RESULTS');

    } catch (e: any) {
      console.error(e);
      setError(e.message || 'Failed to analyze and save interview.');
      setStep('ERROR');
    }
  };
  
  const handleStartOver = () => {
    router.push('/home');
  };
  
  const handleViewDetails = () => {
    if (lastInterviewId) {
      router.push(`/history/${lastInterviewId}`);
    }
  }


  const renderStep = () => {
    switch (step) {
      case 'JOB_DESCRIPTION':
        return (
          <JobDescriptionStep
            onNext={handleJobDescriptionNext}
            initialJobDescription={jobDescription}
          />
        );
      case 'RESUME_INPUT':
        return (
          <ResumeInputStep
            onStart={handleStartInterview}
            onBack={handleResumeBack}
          />
        );
      case 'SUITABILITY_CHECK':
        if (!suitability) {
            return (
                <div className="flex flex-col items-center justify-center gap-4 text-center">
                    <Loader2 className="h-12 w-12 animate-spin text-primary" />
                    <h2 className="font-headline text-2xl">Analyzing Candidate...</h2>
                    <p className="text-muted-foreground">The AI is checking the resume against the job description.</p>
                </div>
            )
        }
        return (
          <SuitabilityStep
            suitability={suitability}
            onProceed={handleProceedToInterview}
            onBack={handleSuitabilityBack}
          />
        );
      case 'INTERVIEW':
        return <InterviewStep questions={questions} onFinish={handleFinishInterview} />;
      case 'ANALYZING':
        return (
          <div className="flex flex-col items-center justify-center gap-4 text-center">
            <Loader2 className="h-12 w-12 animate-spin text-primary" />
            <h2 className="font-headline text-2xl">Analyzing Interview...</h2>
            <p className="text-muted-foreground">The AI is generating feedback and extracting skills.</p>
          </div>
        );
      case 'RESULTS':
        return (
          <ResultsStep
            resumeSkills={resumeSkills}
            interviewSkills={interviewSkills}
            interviewFeedback={interviewFeedback}
            suitability={suitability}
            onStartOver={handleStartOver}
            onViewDetails={handleViewDetails}
            hasDetails={!!lastInterviewId}
          />
        );
      case 'ERROR':
        return (
            <Alert variant="destructive" className="max-w-xl">
                <ServerCrash className="h-4 w-4" />
                <AlertTitle>An Error Occurred</AlertTitle>
                <AlertDescription>
                    {error || "Something went wrong. Please try again later."}
                </AlertDescription>
            </Alert>
        )
      default:
        return null;
    }
  };

  return (
    <div className="flex items-center justify-center bg-background px-4 py-12">
        {renderStep()}
    </div>
  );
}
