
'use client';

import { useAuth } from '@/hooks/use-auth';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Loader2, BrainCircuit } from 'lucide-react';

const GoogleIcon = () => (
    <svg className="mr-2 h-4 w-4" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 488 512">
        <path fill="currentColor" d="M488 261.8C488 403.3 381.5 512 244 512 109.8 512 0 402.2 0 261.8 0 120.8 109.8 8 244 8c66.8 0 126 23.4 172.9 61.9l-76.8 64.4C301.3 112.6 274.1 96 244 96 170.1 96 108.3 154.5 108.3 228.2c0 73.7 61.8 132.3 135.7 132.3 76.9 0 114.3-54.6 118.9-82.6h-119V219h214.3c1.2 10.9 2.2 21.8 2.2 33.4z"></path>
    </svg>
);


export default function LoginPage() {
  const { signInWithGoogle, isUserLoading } = useAuth();

  return (
    <div className="flex min-h-screen items-center justify-center bg-secondary">
      <Card className="w-full max-w-sm">
        <CardHeader className="text-center">
            <div className="flex justify-center items-center gap-2 mb-4">
                <BrainCircuit className="h-8 w-8 text-primary" />
                <span className="text-2xl font-bold">ResumeAI</span>
            </div>
          <CardTitle>Welcome Back</CardTitle>
          <CardDescription>Sign in to continue to your dashboard.</CardDescription>
        </CardHeader>
        <CardContent>
          <Button
            className="w-full"
            onClick={signInWithGoogle}
            disabled={isUserLoading}
          >
            {isUserLoading ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
                <GoogleIcon />
            )}
            Sign in with Google
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
