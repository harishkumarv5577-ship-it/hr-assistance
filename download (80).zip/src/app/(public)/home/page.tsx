'use client';

import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import { BrainCircuit, CheckCircle, Search, Zap, ArrowRight, UserCheck } from 'lucide-react';
import Image from 'next/image';
import Link from 'next/link';

export default function LandingPage() {
  const heroImage = PlaceHolderImages.find(img => img.id === 'hero');

  return (
    <div className="w-full min-h-screen bg-background">
      <header className="border-b bg-white/50 backdrop-blur-md sticky top-0 z-50">
        <div className="container mx-auto flex items-center justify-between p-4 px-6">
          <div className="flex items-center gap-2">
            <div className="bg-primary p-2 rounded-lg">
              <BrainCircuit className="h-6 w-6 text-white" />
            </div>
            <span className="text-2xl font-black tracking-tight font-headline">ResumeAI</span>
          </div>
          <div className="flex items-center gap-4">
            <Button asChild variant="ghost">
              <Link href="/history">History</Link>
            </Button>
            <Button asChild className="rounded-full px-6 shadow-md hover:shadow-lg transition-all">
              <Link href="/interview">Start Now</Link>
            </Button>
          </div>
        </div>
      </header>
      
      <main>
        {/* Hero Section */}
        <section className="container mx-auto flex flex-col items-center py-20 md:py-32 px-6 text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-bold mb-6">
            <Zap className="h-4 w-4" />
            AI-Powered Hiring Efficiency
          </div>
          <h1 className="font-headline text-5xl md:text-7xl font-black tracking-tight max-w-4xl leading-[1.1]">
            Your Intelligent <span className="text-primary">Interview Co-Pilot</span>
          </h1>
          <p className="mt-6 text-xl text-muted-foreground max-w-2xl leading-relaxed">
            ResumeAI streamlines your recruitment workflow by automatically parsing resumes, generating insightful questions, and providing detailed candidate analysis.
          </p>
          <div className="mt-10 flex flex-col sm:flex-row gap-4">
            <Button asChild size="lg" className="h-14 px-8 text-lg rounded-full shadow-xl hover:shadow-2xl transition-all">
              <Link href="/interview">
                Get Started For Free
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="h-14 px-8 text-lg rounded-full">
              <Link href="/history">View Recent Reports</Link>
            </Button>
          </div>
          {heroImage && (
            <div className="mt-16 w-full max-w-5xl relative">
              <div className="absolute -inset-4 bg-primary/20 blur-3xl rounded-full opacity-50 -z-10" />
              <Image
                src={heroImage.imageUrl}
                alt={heroImage.description}
                width={1200}
                height={675}
                className="rounded-2xl shadow-2xl border bg-white p-2"
                data-ai-hint={heroImage.imageHint}
                priority
              />
            </div>
          )}
        </section>

        {/* Features Grid */}
        <section className="bg-white border-y py-24 px-6">
          <div className="container mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-4xl font-black font-headline mb-4">Everything you need to hire faster</h2>
              <p className="text-muted-foreground text-lg max-w-xl mx-auto">From screening to final selection recommendation, we've got you covered.</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
              <Card className="border-none shadow-none bg-secondary/50 p-6">
                <CardHeader>
                  <div className="bg-primary/10 w-12 h-12 rounded-xl flex items-center justify-center mb-4">
                    <Search className="text-primary h-6 w-6" />
                  </div>
                  <CardTitle className="text-2xl font-headline">1. Extract & Score</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground leading-relaxed">Simply upload a resume and job description. Our AI extracts core skills and provides an instant suitability score.</p>
                </CardContent>
              </Card>
              <Card className="border-none shadow-none bg-secondary/50 p-6">
                <CardHeader>
                  <div className="bg-primary/10 w-12 h-12 rounded-xl flex items-center justify-center mb-4">
                    <BrainCircuit className="text-primary h-6 w-6" />
                  </div>
                  <CardTitle className="text-2xl font-headline">2. Smart Questions</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground leading-relaxed">Based on the resume gaps and job requirements, the AI generates personalized questions for the interview.</p>
                </CardContent>
              </Card>
              <Card className="border-none shadow-none bg-secondary/50 p-6">
                <CardHeader>
                  <div className="bg-primary/10 w-12 h-12 rounded-xl flex items-center justify-center mb-4">
                    <UserCheck className="text-primary h-6 w-6" />
                  </div>
                  <CardTitle className="text-2xl font-headline">3. Final Recommendation</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground leading-relaxed">Receive immediate performance feedback and a clear "Hire" or "No Hire" recommendation with reasoning.</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Social Proof */}
        <section className="py-24 px-6 bg-secondary/30">
          <div className="container mx-auto text-center">
            <h2 className="text-4xl font-black font-headline mb-16">Trusted by Recruitment Professionals</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-left">
              {PlaceHolderImages.filter(img => img.id.includes('testimonial')).map((testimonial, i) => (
                <Card key={testimonial.id} className="shadow-lg border-none">
                  <CardContent className="pt-8 p-6">
                    <div className="flex items-center mb-6">
                      <Image 
                        src={testimonial.imageUrl} 
                        alt={testimonial.description} 
                        width={50} 
                        height={50} 
                        className="rounded-full border-2 border-primary/20"
                        data-ai-hint={testimonial.imageHint}
                      />
                      <div className="ml-4">
                        <p className="font-bold">Alex Johnson</p>
                        <p className="text-sm text-primary font-medium">Sr. Tech Recruiter</p>
                      </div>
                    </div>
                    <p className="text-muted-foreground italic text-lg leading-relaxed">
                      "ResumeAI has fundamentally changed how we screen. It saves us 10+ hours per week per manager."
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>
      </main>
      
      <footer className="w-full border-t py-12 bg-white">
        <div className="container mx-auto px-6 text-center">
          <div className="flex items-center justify-center gap-2 mb-6">
            <BrainCircuit className="h-6 w-6 text-primary" />
            <span className="text-xl font-bold font-headline">ResumeAI</span>
          </div>
          <p className="text-muted-foreground text-sm">&copy; {new Date().getFullYear()} ResumeAI. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}