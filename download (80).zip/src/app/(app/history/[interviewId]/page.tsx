
'use client';

import { useEffect } from 'react';
import { useParams } from 'next/navigation';
import { useDoc, useMemoFirebase } from '@/firebase';
import { doc } from 'firebase/firestore';
import { useFirestore } from '@/firebase/provider';
import { Loader2, Star, TrendingUp, TrendingDown, CheckCircle, XCircle } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { format } from 'date-fns';

// Mirroring the structure from backend.json
interface InterviewRecord {
  id: string;
  candidateName: string;
  jobDescription: string;
  conductedAt: { seconds: number; nanoseconds: number };
  suitability: {
    suitabilityScore: number;
    isSuitable: boolean;
    reason: string;
  };
  feedback: {
    feedback: string;
    strengths: string[];
    areasForImprovement: string[];
  };
}

export default function InterviewDetailsPage() {
  const params = useParams();
  const firestore = useFirestore();
  const interviewId = params.interviewId as string;

  const interviewDocRef = useMemoFirebase(() => {
    if (!firestore || !interviewId) return null;
    return doc(firestore, `interviews`, interviewId);
  }, [firestore, interviewId]);

  const { data: interview, isLoading: isLoadingInterview, error } = useDoc<InterviewRecord>(interviewDocRef);

  if (isLoadingInterview) {
    return (
      <div className="flex h-screen w-full items-center justify-center">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mx-auto py-8 md:py-12 w-full max-w-2xl text-center">
        <h2 className="text-2xl font-bold text-destructive">Error</h2>
        <p className="text-muted-foreground">{error.message}</p>
      </div>
    );
  }

  if (!interview) {
    return (
      <div className="container mx-auto py-8 md:py-12 w-full max-w-2xl text-center">
        <h2 className="text-2xl font-bold">Interview Not Found</h2>
        <p className="text-muted-foreground">The requested interview record could not be found.</p>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8 md:py-12 w-full max-w-4xl animate-in fade-in-50">
        <div className="flex items-center gap-4 mb-8">
            <div>
                <h1 className="font-headline text-3xl font-bold">{interview.candidateName}</h1>
                <p className="text-muted-foreground">
                    Interview conducted on {format(new Date(interview.conductedAt.seconds * 1000), 'MMMM d, yyyy')}
                </p>
            </div>
        </div>

        <div className="space-y-6">
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                        <span>Suitability Assessment</span>
                        <Badge variant={interview.suitability.isSuitable ? "default" : "destructive"} className="text-base">
                            {interview.suitability.isSuitable ? <CheckCircle className="mr-2" /> : <XCircle className="mr-2" />}
                            {interview.suitability.isSuitable ? 'Recommended' : 'Not Recommended'}
                        </Badge>
                    </CardTitle>
                </CardHeader>
                <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="md:col-span-2 space-y-2">
                        <h4 className="font-semibold">AI's Reasoning</h4>
                        <p className="text-muted-foreground">{interview.suitability.reason}</p>
                    </div>
                    <div className="flex flex-col items-center justify-center rounded-lg border bg-secondary p-6">
                        <p className="text-sm text-muted-foreground">OVERALL SCORE</p>
                        <p className="text-6xl font-bold text-primary">{interview.suitability.suitabilityScore}<span className="text-2xl text-muted-foreground">/10</span></p>
                    </div>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2"><Star className="text-primary"/> AI Performance Feedback</CardTitle>
                </CardHeader>
                <CardContent>
                    <p className="text-muted-foreground mb-6">{interview.feedback.feedback}</p>
                    <Separator className="my-6" />
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <h4 className="font-semibold text-lg mb-3 flex items-center gap-2 text-green-600">
                                <TrendingUp /> Strengths
                            </h4>
                            <ul className="list-disc list-inside space-y-2 text-muted-foreground">
                                {interview.feedback.strengths.map((strength, index) => (
                                    <li key={`strength-${index}`}>{strength}</li>
                                ))}
                            </ul>
                        </div>
                        <div>
                            <h4 className="font-semibold text-lg mb-3 flex items-center gap-2 text-amber-600">
                                <TrendingDown /> Areas for Improvement
                            </h4>
                            <ul className="list-disc list-inside space-y-2 text-muted-foreground">
                                {interview.feedback.areasForImprovement.map((area, index) => (
                                    <li key={`improvement-${index}`}>{area}</li>
                                ))}
                            </ul>
                        </div>
                    </div>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>Job Description</CardTitle>
                    <CardDescription>This was the job description used for the interview.</CardDescription>
                </CardHeader>
                <CardContent>
                    <p className="text-sm text-muted-foreground whitespace-pre-wrap">{interview.jobDescription}</p>
                </CardContent>
            </Card>
        </div>
    </div>
  );
}
