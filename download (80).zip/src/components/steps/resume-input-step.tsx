"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { FileUp, Sparkles, FileText, ArrowLeft, User } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "../ui/input";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

const formSchema = z.object({
    candidateName: z.string().min(1, { message: "Candidate name is required." }),
    resumeText: z.string().optional(),
    resumeFile: z.any().optional(),
}).refine(data => data.resumeText || data.resumeFile, {
    message: "Please either paste resume text or upload a file.",
    path: ["resumeText"],
});


type ResumeInputStepProps = {
  onStart: (data: {candidateName: string, resumeText?: string, resumeFile?: string, fileName?: string, mimeType?: string}) => void;
  initialResumeText?: string;
  onBack: () => void;
};

export default function ResumeInputStep({ onStart, initialResumeText = '', onBack }: ResumeInputStepProps) {
  const [activeTab, setActiveTab] = useState("text");
  const { toast } = useToast();
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      candidateName: '',
      resumeText: initialResumeText,
    },
  });

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) { // 5MB limit
        toast({
          variant: "destructive",
          title: "File too large",
          description: "Please upload a file smaller than 5MB.",
        });
        form.setValue("resumeFile", null);
        return;
      }
      form.setValue("resumeFile", file);
    }
  };

  async function onSubmit(values: z.infer<typeof formSchema>) {
    if (activeTab === 'file' && values.resumeFile) {
        const file = values.resumeFile as File;
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => {
            const dataUri = reader.result as string;
            onStart({ candidateName: values.candidateName, resumeFile: dataUri, fileName: file.name, mimeType: file.type });
        };
        reader.onerror = (error) => {
            console.error("Error reading file:", error);
            toast({
                variant: "destructive",
                title: "Error reading file",
                description: "There was a problem processing your file. Please try again.",
            });
        };
    } else if (activeTab === 'text' && values.resumeText) {
        if (values.resumeText.length < 100) {
            form.setError("resumeText", { message: "Resume text must be at least 100 characters." });
            return;
        }
        onStart({ candidateName: values.candidateName, resumeText: values.resumeText });
    } else {
       // Manually trigger validation to show the refinement error if both fields are empty
       form.trigger();
    }
  }

  return (
    <div className="w-full max-w-3xl flex flex-col items-center text-center animate-in fade-in-50 zoom-in-95">
        <Card className="mt-8 w-full text-left shadow-lg">
            <CardHeader>
                <CardTitle className="font-headline text-2xl flex items-center gap-2">
                    <Sparkles className="text-accent-foreground" />
                    Provide Candidate's Details
                </CardTitle>
                <CardDescription>
                    Enter the candidate's name and provide their resume by pasting text or uploading a file.
                </CardDescription>
            </CardHeader>
            <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)}>
                    <CardContent className="space-y-6">
                      <FormField
                          control={form.control}
                          name="candidateName"
                          render={({ field }) => (
                          <FormItem>
                              <FormLabel className="flex items-center gap-2"><User /> Candidate Name</FormLabel>
                              <FormControl>
                                <Input 
                                  placeholder="e.g., Jane Doe"
                                  {...field}
                                />
                              </FormControl>
                              <FormMessage />
                          </FormItem>
                          )}
                      />

                      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                        <TabsList className="grid w-full grid-cols-2">
                          <TabsTrigger value="text"><FileText className="mr-2"/> Paste Text</TabsTrigger>
                          <TabsTrigger value="file"><FileUp className="mr-2"/> Upload File</TabsTrigger>
                        </TabsList>
                        <TabsContent value="text" className="pt-4">
                          <FormField
                              control={form.control}
                              name="resumeText"
                              render={({ field }) => (
                              <FormItem>
                                  <FormLabel className="sr-only">Resume Text</FormLabel>
                                  <FormControl>
                                  <Textarea
                                      placeholder="Paste resume text here..."
                                      className="min-h-[250px] text-base"
                                      {...field}
                                  />
                                  </FormControl>
                                  <FormMessage />
                              </FormItem>
                              )}
                          />
                        </TabsContent>
                        <TabsContent value="file" className="pt-4">
                          <FormField
                              control={form.control}
                              name="resumeFile"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel className="sr-only">Resume File</FormLabel>
                                  <FormControl>
                                    <Input 
                                      type="file" 
                                      onChange={handleFileChange} 
                                      accept="image/*,.pdf,.doc,.docx,.txt"
                                      className="pt-2 text-base h-11"
                                    />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                           />
                           <p className="text-xs text-muted-foreground mt-2">Supported formats: PDF, DOCX, DOC, TXT, PNG, JPG. Max file size: 5MB.</p>
                        </TabsContent>
                      </Tabs>
                    </CardContent>
                    <CardFooter className="flex justify-between">
                        <Button type="button" variant="outline" onClick={onBack}>
                            <ArrowLeft />
                            Back
                        </Button>
                        <Button type="submit" size="lg">
                            Generate Interview & Start
                        </Button>
                    </CardFooter>
                </form>
            </Form>
        </Card>
    </div>
  );
}
