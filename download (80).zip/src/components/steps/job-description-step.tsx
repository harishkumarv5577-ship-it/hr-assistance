"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Briefcase } from "lucide-react";
import { useRouter } from "next/navigation";

const formSchema = z.object({
    jobDescription: z.string().min(10, { message: "Job description must be at least 10 characters." }),
});

type JobDescriptionStepProps = {
  onNext: (data: { jobDescription: string }) => void;
  initialJobDescription?: string;
};

export default function JobDescriptionStep({ onNext, initialJobDescription = '' }: JobDescriptionStepProps) {
  const router = useRouter();
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      jobDescription: initialJobDescription,
    },
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    onNext(values);
  }

  return (
    <div className="w-full max-w-3xl flex flex-col items-center text-center pt-12">
        <div className="animate-in fade-in-50 zoom-in-95 duration-500">
            <h1 className="font-headline text-4xl md:text-5xl font-bold tracking-tight">
                Welcome to <span className="text-primary">ResumeAI</span>
            </h1>
            <p className="mt-4 text-lg text-muted-foreground max-w-2xl">
                Streamline your hiring process. Start by telling us about the role, and our AI will tailor the interview.
            </p>
        </div>

        <Card className="mt-8 w-full text-left shadow-lg animate-in fade-in-50 zoom-in-95 duration-500 delay-300 fill-mode-both">
            <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)}>
                    <CardHeader>
                        <CardTitle className="font-headline text-2xl flex items-center gap-2">
                            <Briefcase className="text-primary" />
                            Describe the Ideal Candidate
                        </CardTitle>
                        <CardDescription>
                            Paste the job description below. This will help the AI generate relevant questions.
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                        <FormField
                            control={form.control}
                            name="jobDescription"
                            render={({ field }) => (
                            <FormItem>
                                <FormLabel className="sr-only">Job Description</FormLabel>
                                <FormControl>
                                <Textarea
                                    placeholder="e.g., 'We are looking for a Senior Software Engineer with 5+ years of experience in React...'"
                                    className="min-h-[250px] text-base"
                                    {...field}
                                />
                                </FormControl>
                                <FormMessage />
                            </FormItem>
                            )}
                        />
                    </CardContent>
                    <CardFooter>
                    <Button type="submit" className="w-full" size="lg">
                        Next: Add Resume
                    </Button>
                    </CardFooter>
                </form>
            </Form>
        </Card>
    </div>
  );
}
