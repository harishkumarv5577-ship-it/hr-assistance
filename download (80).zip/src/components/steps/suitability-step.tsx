"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckCircle, XCircle, ArrowLeft, ArrowRight } from "lucide-react";
import { Progress } from "../ui/progress";

export type Suitability = {
  isSuitable: boolean;
  reason: string;
  suitabilityScore: number;
};

type SuitabilityStepProps = {
  suitability: Suitability;
  onProceed: () => void;
  onBack: () => void;
};

export default function SuitabilityStep({ suitability, onProceed, onBack }: SuitabilityStepProps) {
  const scoreColor = suitability.suitabilityScore >= 8 ? 'bg-green-500' : suitability.suitabilityScore >= 5 ? 'bg-yellow-500' : 'bg-red-500';

  return (
    <Card className="w-full max-w-2xl shadow-lg animate-in fade-in-50 zoom-in-95">
      <CardHeader>
        <CardTitle className="font-headline text-2xl flex items-center gap-2">
          {suitability.isSuitable ? (
            <CheckCircle className="text-green-500" />
          ) : (
            <XCircle className="text-red-500" />
          )}
          Candidate Suitability Analysis
        </CardTitle>
        <CardDescription>
          The AI has analyzed the candidate's resume against the job description.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="text-center">
            <p className="text-muted-foreground text-sm mb-2">Suitability Score</p>
            <p className="font-bold text-5xl">{suitability.suitabilityScore}/10</p>
            <Progress value={suitability.suitabilityScore * 10} className={`mt-2 h-3 [&>div]:${scoreColor}`} />
        </div>
        <div className="rounded-lg border bg-card p-4">
            <h3 className="font-headline text-lg mb-2">AI's Reasoning</h3>
            <p className="text-sm text-muted-foreground">{suitability.reason}</p>
        </div>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button variant="outline" onClick={onBack}>
          <ArrowLeft />
          Back
        </Button>
        <Button onClick={onProceed}>
          Proceed to Interview
          <ArrowRight />
        </Button>
      </CardFooter>
    </Card>
  );
}
