
"use client";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { FileText, Mic, Star, TrendingUp, TrendingDown, Home, CheckCircle, XCircle, FileSearch, UserCheck } from "lucide-react";
import type { Suitability } from "./suitability-step";

export type InterviewFeedback = {
    feedback: string;
    strengths: string[];
    areasForImprovement: string[];
    selectionRecommendation: {
        decision: string;
        reasoning: string;
    };
} | null;

type ResultsStepProps = {
  resumeSkills: string[];
  interviewSkills: string[];
  interviewFeedback: InterviewFeedback;
  suitability: Suitability | null;
  onStartOver: () => void;
  onViewDetails: () => void;
  hasDetails: boolean;
};

export default function ResultsStep({ resumeSkills, interviewSkills, interviewFeedback, suitability, onStartOver, onViewDetails, hasDetails }: ResultsStepProps) {
  const decision = interviewFeedback?.selectionRecommendation?.decision;
  const decisionColor = 
    decision === 'Strong Hire' ? 'bg-green-600' : 
    decision === 'Hire' ? 'bg-green-500' : 
    decision === 'Maybe' ? 'bg-amber-500' : 
    decision === 'No Hire' ? 'bg-red-500' : 
    'bg-muted';

  return (
    <Card className="w-full max-w-4xl shadow-lg animate-in fade-in-50 zoom-in-95">
      <CardHeader className="text-center">
        <CardTitle className="font-headline text-3xl">Interview Analysis Complete</CardTitle>
        <CardDescription>The interview record has been saved. Here is the final selection recommendation from the AI.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-8">
        
        {interviewFeedback?.selectionRecommendation && (
            <div className="rounded-xl border-2 border-primary overflow-hidden shadow-md">
                <div className={`${decisionColor} p-4 text-white flex items-center justify-between`}>
                    <div className="flex items-center gap-2">
                        <UserCheck className="h-6 w-6" />
                        <span className="font-bold text-xl uppercase tracking-wider">Final Recommendation</span>
                    </div>
                    <Badge variant="outline" className="text-white border-white text-lg px-4 py-1">
                        {decision}
                    </Badge>
                </div>
                <div className="p-6 bg-card">
                    <p className="text-lg font-medium mb-2">Reasoning:</p>
                    <p className="text-muted-foreground italic leading-relaxed">
                        {interviewFeedback.selectionRecommendation.reasoning}
                    </p>
                </div>
            </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {suitability && (
                <div className="rounded-lg border bg-card p-6 flex flex-col justify-between">
                    <div>
                        <h3 className="font-headline text-xl mb-4 flex items-center gap-2">
                            {suitability.isSuitable ? (
                                <CheckCircle className="text-green-500" />
                            ) : (
                                <XCircle className="text-red-500" />
                            )}
                            Resume Suitability
                        </h3>
                        <p className="text-muted-foreground text-sm leading-relaxed">{suitability.reason}</p>
                    </div>
                    <div className="text-right mt-4 pt-4 border-t">
                        <p className="text-muted-foreground text-xs uppercase font-bold">Resume Score</p>
                        <p className="font-bold text-3xl text-primary">{suitability.suitabilityScore}/10</p>
                    </div>
                </div>
            )}

            {interviewFeedback && (
                <div className="rounded-lg border bg-card p-6">
                    <h3 className="font-headline text-xl mb-4 flex items-center gap-2">
                        <Star className="text-primary" />
                        Performance Summary
                    </h3>
                    <p className="text-muted-foreground text-sm leading-relaxed">{interviewFeedback.feedback}</p>
                    <div className="mt-4 pt-4 border-t flex flex-wrap gap-2">
                        <Badge variant="outline" className="text-green-600 border-green-200">
                            <TrendingUp className="mr-1 h-3 w-3" /> {interviewFeedback.strengths.length} Strengths
                        </Badge>
                        <Badge variant="outline" className="text-amber-600 border-amber-200">
                            <TrendingDown className="mr-1 h-3 w-3" /> {interviewFeedback.areasForImprovement.length} Areas for Improvement
                        </Badge>
                    </div>
                </div>
            )}
        </div>

        <Separator />

        <div>
            <h3 className="font-headline text-xl mb-4 text-center">Skill Comparison</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="rounded-lg border bg-card p-4">
                <h3 className="font-headline text-lg mb-4 flex items-center gap-2">
                <FileText className="text-primary" />
                Resume Skills
                </h3>
                {resumeSkills.length > 0 ? (
                <div className="flex flex-wrap gap-2">
                    {resumeSkills.map((skill, index) => (
                    <Badge key={`resume-skill-${index}`} variant="secondary">{skill}</Badge>
                    ))}
                </div>
                ) : (
                <p className="text-sm text-muted-foreground">No specific skills were extracted from the resume.</p>
                )}
            </div>
            <div className="rounded-lg border bg-card p-4">
                <h3 className="font-headline text-lg mb-4 flex items-center gap-2">
                <Mic className="text-primary" />
                Interview Skills
                </h3>
                {interviewSkills.length > 0 ? (
                <div className="flex flex-wrap gap-2">
                    {interviewSkills.map((skill, index) => (
                    <Badge key={`interview-skill-${index}`} variant="default">{skill}</Badge>
                    ))}
                </div>
                ) : (
                    <p className="text-sm text-muted-foreground">No additional skills were identified during the interview.</p>
                )}
            </div>
            </div>
        </div>
      </CardContent>
      <CardFooter className="flex flex-col items-center gap-4 pt-4">
        <Separator />
        <div className="flex items-center gap-4">
            <Button onClick={onStartOver} variant="secondary">
                <Home className="mr-2 h-4 w-4" />
                Back to Home
            </Button>
            {hasDetails && (
                <Button onClick={onViewDetails} size="lg" className="px-8 shadow-md">
                    <FileSearch className="mr-2 h-5 w-5" />
                    View Detailed Report
                </Button>
            )}
        </div>
      </CardFooter>
    </Card>
  );
}
