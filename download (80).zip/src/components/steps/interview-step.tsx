"use client";

import { useState, useEffect } from "react";
import { ArrowLeft, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "../ui/label";

type InterviewStepProps = {
  questions: string[];
  onFinish: (answers: string[]) => void;
};

export default function InterviewStep({ questions, onFinish }: InterviewStepProps) {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<string[]>(() => Array(questions.length).fill(""));
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    setProgress(((currentQuestionIndex + 1) / questions.length) * 100);
  }, [currentQuestionIndex, questions.length]);

  const handleNext = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    } else {
      onFinish(answers);
    }
  };

  const handlePrevious = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(currentQuestionIndex - 1);
    }
  };

  const handleAnswerChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const newAnswers = [...answers];
    newAnswers[currentQuestionIndex] = e.target.value;
    setAnswers(newAnswers);
  };

  const isLastQuestion = currentQuestionIndex === questions.length - 1;

  return (
    <Card className="w-full max-w-2xl shadow-lg animate-in fade-in-50 zoom-in-95">
      <CardHeader>
        <div className="mb-4">
          <p className="text-sm text-muted-foreground mb-2">Question {currentQuestionIndex + 1} of {questions.length}</p>
          <Progress value={progress} className="w-full" />
        </div>
        <CardTitle className="font-headline text-2xl">{questions[currentQuestionIndex]}</CardTitle>
        <CardDescription>Please provide a detailed answer below.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid w-full gap-2">
            <Label htmlFor="answer" className="sr-only">Your Answer</Label>
            <Textarea
            id="answer"
            placeholder="Type your answer here..."
            value={answers[currentQuestionIndex]}
            onChange={handleAnswerChange}
            rows={8}
            className="text-base"
            />
        </div>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button variant="outline" onClick={handlePrevious} disabled={currentQuestionIndex === 0}>
          <ArrowLeft />
          Previous
        </Button>
        <Button onClick={handleNext} disabled={!answers[currentQuestionIndex]}>
          {isLastQuestion ? "Finish & Analyze" : "Next"}
          {!isLastQuestion && <ArrowRight />}
        </Button>
      </CardFooter>
    </Card>
  );
}
