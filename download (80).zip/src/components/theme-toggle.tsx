'use client';

import * as React from 'react';
import { useTheme } from 'next-themes';
import { Button } from '@/components/ui/button';
import { Moon, Sun, Monitor } from 'lucide-react';
import { cn } from '@/lib/utils';

export function ThemeToggle() {
  const { theme, setTheme } = useTheme();

  return (
    <div className="grid grid-cols-3 gap-2 rounded-lg border p-1">
      <Button
        variant="ghost"
        size="sm"
        onClick={() => setTheme('light')}
        className={cn(theme === 'light' && 'bg-accent text-accent-foreground')}
      >
        <Sun className="mr-2" />
        Light
      </Button>
      <Button
        variant="ghost"
        size="sm"
        onClick={() => setTheme('dark')}
        className={cn(theme === 'dark' && 'bg-accent text-accent-foreground')}
      >
        <Moon className="mr-2" />
        Dark
      </Button>
      <Button
        variant="ghost"
        size="sm"
        onClick={() => setTheme('system')}
        className={cn(theme === 'system' && 'bg-accent text-accent-foreground')}
      >
        <Monitor className="mr-2" />
        System
      </Button>
    </div>
  );
}
