
'use client';

import React from 'react';
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
} from '@/components/ui/sidebar';
import { BrainCircuit, LayoutDashboard, FileText, Settings, LogOut, History } from 'lucide-react';
import { usePathname, useRouter } from 'next/navigation';
import { useAuth } from '@/hooks/use-auth';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Skeleton } from '../ui/skeleton';

export function AppSidebar() {
  const router = useRouter();
  const pathname = usePathname();
  const { user, signOut, isUserLoading } = useAuth();

  return (
    <Sidebar>
      <SidebarHeader>
        <div className="flex items-center gap-2">
            <BrainCircuit className="h-6 w-6 text-primary" />
            <span className="font-headline text-xl font-bold">ResumeAI</span>
        </div>
      </SidebarHeader>
      <SidebarContent>
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton
              onClick={() => router.push('/interview')}
              isActive={pathname === '/interview'}
              tooltip="New Interview"
            >
              <FileText />
              <span>New Interview</span>
            </SidebarMenuButton>
          </SidebarMenuItem>
          <SidebarMenuItem>
            <SidebarMenuButton
              onClick={() => router.push('/history')}
              isActive={pathname.startsWith('/history')}
              tooltip="Interview History"
            >
              <History />
              <span>History</span>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarContent>
      <SidebarFooter>
        <SidebarMenu>
           <SidebarMenuItem>
            <SidebarMenuButton
                onClick={() => router.push('/settings')}
                isActive={pathname === '/settings'}
                tooltip="Settings"
                >
                <Settings />
                <span>Settings</span>
            </SidebarMenuButton>
            </SidebarMenuItem>
            <SidebarMenuItem>
                <SidebarMenuButton onClick={signOut} tooltip="Log Out">
                    <LogOut />
                    <span>Log Out</span>
                </SidebarMenuButton>
            </SidebarMenuItem>
        </SidebarMenu>
        <div className="flex items-center gap-3 p-2">
            {isUserLoading ? (
                <>
                    <Skeleton className="h-8 w-8 rounded-full" />
                    <Skeleton className="h-4 w-24" />
                </>
            ) : user ? (
                <>
                    <Avatar className="h-8 w-8">
                        <AvatarImage src={user.photoURL ?? ''} />
                        <AvatarFallback>{user.displayName?.charAt(0) ?? 'U'}</AvatarFallback>
                    </Avatar>
                    <span className="text-sm font-medium truncate">{user.displayName ?? user.email}</span>
                </>
            ) : null}
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}
