import React from 'react';

export function Footer() {
  return (
    <footer className="w-full border-t border-border/40 py-4">
      <div className="container mx-auto text-center text-sm text-muted-foreground">
        <p>&copy; {new Date().getFullYear()} ResumeAI. All rights reserved.</p>
      </div>
    </footer>
  );
}
