export const firebaseConfig = {
  "projectId": "studio-9160778777-3b6e6",
  "appId": "1:785016095893:web:9692812a69f3022106079c",
  "apiKey": "AIzaSyDUfaSktcif1zdSWqexlfKDL9sJ8OEug_k",
  "authDomain": "studio-9160778777-3b6e6.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "785016095893"
};
